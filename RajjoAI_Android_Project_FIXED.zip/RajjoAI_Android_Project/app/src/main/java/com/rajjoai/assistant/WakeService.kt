package com.rajjoai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.content.Context
import android.util.Log
import java.util.Locale

class WakeService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private var processing = false
    private var lastRestart = 0L
    private val channelId = "rajjo_ai_listening"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId)
                .setContentTitle("Rajjo AI চালু আছে")
                .setContentText("‘রাজ্জো এআই’ ডাক শোনার চেষ্টা করছে — বন্ধ করতে অ্যাপ খুলুন")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("Rajjo AI চালু আছে")
                .setContentText("ভয়েস অ্যাসিস্ট্যান্ট চলছে")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        }
        startForeground(7, notification)
        tts = TextToSpeech(this, this)
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { scheduleListen() }
                override fun onResults(results: android.os.Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    onHeard(heard)
                    scheduleListen()
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
            })
            listen()
        }
    }

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) tts?.language = Locale("bn", "BD")
    }

    private fun listen() {
        if (processing || recognizer == null) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (e: Exception) { Log.w("RajjoAI", "startListening failed", e); scheduleListen() }
    }

    private fun scheduleListen() {
        val now = System.currentTimeMillis()
        val delay = maxOf(1200L, 2200L - (now - lastRestart))
        lastRestart = now
        android.os.Handler(mainLooper).postDelayed({ if (!processing) listen() }, delay)
    }

    private var awaitingCommand = false

    private fun normalize(text: String): String {
        return text.lowercase(Locale.ROOT)
            .replace("রাজ্জো", "রাজ্য")
            .replace("রাজো", "রাজ্য")
            .replace("rajjo", "রাজ্য")
            .replace("rajo", "রাজ্য")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun onHeard(text: String) {
        val q = normalize(text)
        if (q.isBlank()) return

        val hasWake = q.contains("রাজ্য") || q.contains("রাজ্য এআই")
        val command = q
            .replace("রাজ্য এআই", "")
            .replace("রাজ্য", "")
            .trim()

        if (awaitingCommand) {
            awaitingCommand = false
            processing = false
            executeCommand(q)
            return
        }

        if (hasWake) {
            if (command.isNotBlank()) {
                executeCommand(command)
            } else {
                awaitingCommand = true
                processing = true
                say("জি স্যার, বলুন।")
                android.os.Handler(mainLooper).postDelayed({
                    if (awaitingCommand) {
                        processing = false
                        listen()
                    }
                }, 5000)
            }
        }
    }

    private fun executeCommand(command: String) {
        val q = normalize(command)

        when {
            q.contains("ফেসবুক") || q.contains("facebook") -> openPackage("com.facebook.katana", "ফেসবুক")
            q.contains("মেসেঞ্জার") || q.contains("messenger") -> openPackage("com.facebook.orca", "মেসেঞ্জার")
            q.contains("হোয়াটসঅ্যাপ") || q.contains("হোয়াটসঅ্যাপ") || q.contains("whatsapp") -> openPackage("com.whatsapp", "হোয়াটসঅ্যাপ")
            q.contains("ইনস্টাগ্রাম") || q.contains("instagram") -> openPackage("com.instagram.android", "ইনস্টাগ্রাম")
            q.contains("ক্রোম") || q.contains("chrome") -> openPackage("com.android.chrome", "ক্রোম")
            q.contains("ইউটিউব") || q.contains("youtube") -> openPackage("com.google.android.youtube", "ইউটিউব")
            q.contains("জিমেইল") || q.contains("gmail") -> openPackage("com.google.android.gm", "জিমেইল")
            q.contains("প্লে স্টোর") || q.contains("play store") -> openPackage("com.android.vending", "প্লে স্টোর")
            q.contains("সেটিং") || q.contains("settings") -> openIntent(Intent(Settings.ACTION_SETTINGS), "সেটিংস")
            q.contains("ক্যামেরা") || q.contains("camera") -> openIntent(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE), "ক্যামেরা")
            q.contains("ফোন") || q.contains("ডায়াল") || q.contains("dialer") -> openIntent(Intent(Intent.ACTION_DIAL), "ফোন")
            q.contains("গুগল") || q.contains("google") -> openIntent(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com")), "গুগল")
            else -> openInstalledApp(q)
        }
    }

    private fun openPackage(packageName: String, appName: String) {
        val pm = packageManager
        val launch = pm.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            try {
                say("$appName খুলছি।")
                startActivity(launch)
                return
            } catch (e: Exception) {
                Log.w("RajjoAI", "Could not open $packageName", e)
            }
        }
        openInstalledApp(appName)
    }

    private fun openIntent(intent: Intent, appName: String) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (intent.resolveActivity(packageManager) != null) {
                say("$appName খুলছি।")
                startActivity(intent)
            } else {
                say("$appName এই ফোনে পাওয়া যায়নি।")
            }
        } catch (e: Exception) {
            Log.w("RajjoAI", "Could not open intent", e)
            say("$appName খোলা যায়নি।")
        }
    }

    private fun openInstalledApp(request: String) {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        val wanted = normalize(request)
        val match = apps.firstOrNull { info ->
            val label = info.loadLabel(pm).toString()
            val pkg = info.activityInfo.packageName
            val normalizedLabel = normalize(label)
            wanted.contains(normalizedLabel) || normalizedLabel.contains(wanted) || pkg.lowercase(Locale.ROOT).contains(wanted.replace(" ", ""))
        }
        if (match != null) {
            val launch = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                setClassName(match.activityInfo.packageName, match.activityInfo.name)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            }
            try {
                say("${match.loadLabel(pm)} খুলছি।")
                startActivity(launch)
                return
            } catch (e: Exception) {
                Log.w("RajjoAI", "Generic app launch failed", e)
            }
        }
        say("$request নামে কোনো অ্যাপ খুঁজে পাইনি।")
    }

    private fun say(text: String) {
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rajjo_reply")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Rajjo AI microphone", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Rajjo AI voice assistant foreground service"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

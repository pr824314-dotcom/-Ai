package com.rajjoai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCode = 21

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
        }
        val title = TextView(this).apply {
            text = "রাজ্য AI\n\nবাংলা Voice Assistant"
            textSize = 24f
        }
        val info = TextView(this).apply {
            text = "\nঅন্য অ্যাপ থেকে YouTube/Facebook বদলানো, Back, Home ও Recent-এর মতো ফোন নেভিগেশন কমান্ড চালাতে Accessibility অনুমতি চালু করতে হবে।\n"
            textSize = 16f
        }
        val accessibility = Button(this).apply { text = "Accessibility চালু করো" }
        val start = Button(this).apply { text = "রাজ্য AI চালু করো" }
        val stop = Button(this).apply { text = "শোনা বন্ধ করো" }
        layout.addView(title); layout.addView(info); layout.addView(accessibility); layout.addView(start); layout.addView(stop)
        setContentView(layout)

        accessibility.setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            catch (_: Exception) { Toast.makeText(this, "Accessibility settings খোলা যায়নি", Toast.LENGTH_LONG).show() }
        }
        start.setOnClickListener {
            val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), requestCode)
            else startAssistant()
        }
        stop.setOnClickListener {
            stopService(Intent(this, WakeService::class.java))
            Toast.makeText(this, "রাজ্য AI বন্ধ করা হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startAssistant()
        else Toast.makeText(this, "মাইক্রোফোনের অনুমতি দরকার", Toast.LENGTH_LONG).show()
    }

    private fun startAssistant() {
        try {
            val intent = Intent(this, WakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            Toast.makeText(this, "রাজ্য AI চালু হয়েছে", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "চালু করা যায়নি: ${e.message ?: "অজানা সমস্যা"}", Toast.LENGTH_LONG).show()
        }
    }
}
